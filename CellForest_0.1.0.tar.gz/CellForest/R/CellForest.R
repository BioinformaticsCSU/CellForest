#' CellForest
#'
#' Cluster samples based on functional similarity using gene-set based local similarity
#' @param data  A expression data matrix,gene in rows and samples in columns.
#' @param kcluster  The number of clusters to output.
#' @param N  The number of sampling in gene space.
#' @param ncores The number of cores to be used when the program running in parallel.
#' @param minprob Threshold of the probability to select genes.
#' @param toppct Ratio of the number of genes to be used when computing the cluster results.
#' @return geneImportance The weights of genes calculated by function randomForest.
#' @return CM similarity matrix calculated by Cell Forest.
#' @return cluster predicated clusters by using CM and Hierarchical Clustering.
#' @keywords clustering, unsupervised feature selection
#' @export
#' @author Hongdong Li, lhdcsu@gmail.com, Central South University.
#' @examples
#' data(cfdemo)
#' result = CellForest(data,kcluster = 3,N = 10)
#' performance = evalcluster(label,result$cluster)



CellForest<-function(data,kcluster,N,ncores=-1,minprob=0.3,toppct=seq(0.1,1,by=0.1)){
  rgene=-1
  method=c("freq")
  labelknown=NULL
  errorrate=NULL
  clustermethod=c("SC3","kmeans")
  randomlabel=F
  pctgenes=-1
  
  library(foreach)
  library(doParallel)
  if (ncores==-1){ncores=detectCores()-1}
  if (length(method)==1){method=method[1]}
  if (length(clustermethod)>1) {clustermethod="sc3"}
  clustermethod=tolower(clustermethod)
  
  nsample=ncol(data)
  ngene=nrow(data)
  # if (max(toppct) > ngene){kc=which(toppct>ngene)[1]; toppct=toppct[1:(kc-1)]}
  geneweight0=rep(0,length=ngene)
  names(geneweight0)=rownames(data)
  
  
  
  ################################################################
  ################################################################
  ############# decide how to generate random gene sub-space
  ################################################################
  if (rgene<=0){  # equally divide: K-fold CV
    # divide genes in N groups randomly
    group=c(1:ngene-1) %% N +1
    rand_index=sample(group)
  }else{  # ranomly sampling: like MCCV
    Q=floor(ngene*rgene)
  }
  
  
  # Main
  # prepare data for parallelization
  # print(labelknown)
  # print(errorrate)
  DATA=list()
  LABEL=list()
  cat("Gene subset sampling...","\n")
  for (j in 1:N){
    
    # step 1: generate sub-datasets
    if (rgene>0){
      subseti=sample(ngene,Q)
      Xi=t(data[subseti,])
    }else{
      subseti=which(rand_index!=j)
      Xi=t(data[subseti,])
    }
    
    
    # step 2: generate labels by clustering anlaysis
    if (!is.null(labelknown) && !is.null(errorrate)){
      plabel=gen_errorlabel(labelknown,errorrate)
      print("error label used")
      
    }else{
      if (clustermethod=="sc3"){
        cmi=sc3cm(t(Xi),kcluster,verbose=0)
      }else if (clustermethod=="kmeans"){
        cmi=cluster2cm(kmeans(Xi,kcluster)$cluster)
      }else if (clustermethod=="hclust"){
        cmi=cluster2cm(hc(Xi,kcluster))
      }
      plabel=hc(cmi,kcluster)
    }
    
    
    
    # step 3: whether to further randomize labels
    if (randomlabel){
      plabel=sample(plabel)
    }
    
    
    #step 4: record sub-datasets and cell labels
    DATA[[j]]=Xi
    LABEL[[j]]=plabel
  }
  
  # run Feature selection
  cat("Run randomForest for feature selection.\n")
  myCluster <- makeCluster(ncores)
  registerDoParallel(myCluster)
  task=1:N
  geneweight <- foreach(j = task,.combine="rbind") %dopar% {
    library(randomForest)
    rf=randomForest(DATA[[j]],factor(LABEL[[j]]),importance = T)
    grank=rf$importance[,kcluster+1]
    
    wj=geneweight0
    if (method=="freq"){
      goodgenes=names(grank[grank>0])
      wj[goodgenes]=1
    }else{
      wj[names(grank)]=grank
    }
    
    wj # this is the value to return 
  }
  stopCluster(myCluster)
  
  geneweight=colSums(geneweight)/N
  geneweight0=geneweight
  
  # find optimal genes
  
  if(pctgenes>0){
    nselgenes=round(ngene*pctgenes)
  }else{
    nselgenes=sum(geneweight>=minprob)
  }
  
  cat(nselgenes,' genes with freq >= ',minprob,'\n')
  
  cat("Gene subset evaluation.\n")
  geneweight=geneweight[order(-geneweight)]
  
  CMall=list()
  CMavg=matrix(0,nsample,nsample)
  clusters=list()
  for (g in 1:length(toppct)){
    cat("Evaluate the top ",toppct[g]*100,"% genes","\n")
    optgenes=names(geneweight[1:floor(nselgenes*toppct[g])])
    cmg=sc3cm(data[optgenes,],kcluster,verbose=0)
    
    
    plabel=hc(cmg,kcluster)
    clusters[[g]]=plabel
    
    
    CMall[[g]]=cmg
    CMavg=CMavg+cmg
  }
  CMavg=CMavg/length(toppct)
  cluster=hc(CMavg,kcluster)
  
  
  return(list(geneImportance=geneweight0,CM=CMavg,LABEL=LABEL,cluster=cluster,CMall=CMall,clusterall=clusters,toppct=toppct,minprob=minprob,N=N,kcluster=kcluster,clustermethod=clustermethod))
}



gen_errorlabel<-function(labelknown,errorrate){
  # basic
  n=length(labelknown)
  labelerror=labelknown
  nr=round(n*errorrate)
  ulabel=unique(labelknown)
  randindex=sample(n,nr)
  # if (nr<1){nr=1}
  
  
  # randomize label
  if(nr==1) {
    rlabel=sample(setdiff(ulabel,labelknown[randindex]),1)
    labelerror[randindex]=rlabel
    
  }else if (nr>1){
    labelerror[randindex]=sample(labelerror[randindex])
  }
  return(labelerror)
}



sc3cm<-function(X,kcluster,nstart=1000,niter=1e9,verbose=1){
  # Obtain a consensus matrix generated by the SC3 method.
  # X: A expression data matrix,gene in rows and samples in columns.
  # kcluster: The number of clusters to output.
  # nstart: nstart parameter passed to kmeans function. Can be set manually. Default: 1000.
  # niter: iter.max parameter passed to kmeans function. Default: 1e9.
  # verbose: defines whether to output the operation being performed at the console.
  
  # library(foreach)
  # library(doParallel)
  
  ncores=detectCores()-1
  # d-region
  nsample=ncol(X)
  
  if(nsample>2000)
    nstart = 50
  
  nregion=floor(nsample*0.04):ceiling(nsample*0.07)
  nregion=nregion[which(nregion>=2)]
  if (length(nregion)==0){nregion=2}
  if (length(nregion)>15){nregion=sample(nregion,15)}
  
  
  # distance matrix
  D=list()
  D[[1]]=as.matrix(compute_dist(X,"euclidean"))
  D[[2]]=as.matrix(compute_dist(X,"spearman"))
  D[[3]]=as.matrix(compute_dist(X,"pearson"))
  
  
  # MATRIX decomposition
  grid0=expand.grid(1:length(D),1:2)
  myCluster <- makeCluster(ncores)
  registerDoParallel(myCluster)
  task=1:nrow(grid0)
  # print(grid0)
  DL0=list()
  DL0 <- foreach(j = task, .export=c("pca","calLaplacian")) %dopar% {
    # source("/Users/hdl/Documents/Study/mypaper/carf/code/subroutines.R")
    # library(SC3)
    igrid=grid0[j,]
    dim1=as.numeric(igrid[1])
    dim2=as.numeric(igrid[2])
    if (dim2==1){
      U=pca(D[[dim1]],scale = TRUE)
    }else if (dim2 == 2){
      U=calLaplacian(D[[dim1]])
    }
    U
  }
  stopCluster(myCluster)
  iter=1
  DL=list()
  for (j in 1:length(DL0)){
    if (is.matrix(DL0[[j]]))  {DL[[iter]]=DL0[[j]]; iter=iter+1} }
  
  
  # consensus
  if (verbose==1) {print("SC3: calculating consensus matrix")}
  myCluster <- makeCluster(ncores)
  registerDoParallel(myCluster)
  grid=expand.grid(1:length(DL),nregion)
  # print(grid)
  task=1:nrow(grid)
  CM <- foreach(j = task,.combine="+",.export = "cluster2cm") %dopar% {
    # library(cluster)
    jgrid=grid[j,]
    dim1=as.numeric(jgrid[1])
    dim2=as.numeric(jgrid[2])
    # source("/Users/hdl/Documents/Study/mypaper/carf/code/subroutines.R")
    clustj=kmeans(DL[[dim1]][,1:dim2],kcluster,iter.max=niter,nstart=nstart)$cluster
    CMj=cluster2cm(clustj)
  }
  CM=CM/max(CM)
  stopCluster(myCluster)
  if (verbose==1) {print("SC3: done")}
  
  CM=CM/max(CM)
  return(CM)
}

compute_dist<-function(X,distmethod=c("pearson","euclidean","spearman")){
  # calculate distance between columns
  # X: A expression data matrix,gene in rows and samples in columns.
  
  if (distmethod %in% c("pearson","spearman")){
    corr = cor(X,method=distmethod)
    D=as.dist(1-corr)
  }else if(distmethod == "euclidean"){
    D=as.dist(dist(t(X),method=distmethod))
  }
  return(D)
}

pca<-function(X,scale=TRUE){
  #pca
  pc=try(prcomp(X,scale=scale),silent=TRUE)
  if ("rotation" %in% names(pc)){
    scores=pc$rotation
  }else{
    scores="none"
  }
  return(scores)
}

calLaplacian<-function(dists){
  # L <- norm_laplacian(dists)
  # L <- laplacian(dists)
  A = dists
  A = exp(-A/max(A))
  D_row = diag(x=apply(A,1,sum)^-0.5)
  D_col = diag(x=apply(A,2,sum)^-0.5)
  L = diag(x=1,ncol(A),ncol(A)) - D_row%*%A%*%D_col
  l <- eigen(L)
  # sort eigenvectors by their eigenvalues
  D=l$vectors[, order(l$values)]
  return(D)
}

cluster2cm<-function(cluster){
  # convert cluster vector to a consensus matrix
  uc=unique(cluster)
  n=length(cluster)
  CM=matrix(0,n,n)
  for (v in uc){
    kv=which(cluster==v)
    CM[kv,kv] = 1
  }
  return(CM)
}

hc<-function(X,k){
  #Hierarchical Clustering
  # tree=hclust(dist(X))
  tree=hclust(as.dist(1-X))
  cluster = cutree(tree,k)
  
  return(cluster)
}
